﻿using ASP.netMVCfinalProject.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;

namespace ASP.netMVCfinalProject.Controllers
{
    public class HomeController : Controller
    {
        //Global variable
        public const string SessionFName = "_fname";
        public const string SessionLName = "_lname";
        public const string SessionEmail = "_email";
        public const string SessionProfileError = "_ProfileError";
        public const string SessionSignupError = "_SessionSignupError";
        public const string SessionLoginError = "_SessionLoginError";
        //public const string SessionApi = "_SessionApi";

        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        }

        /* ---- Contact Functionality Start ---- */
        public IActionResult Contact()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Contact(Contact contact)
        {
            if (ModelState.IsValid)
            {
                string userIdentifier = HttpContext.Session.GetString(SessionEmail); ;
                SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=mvcFinalProject;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
                string insert = "INSERT INTO [mvcFinalProject].[dbo].[Mes] ([fullName],[email], [subject],[message],[userIdentifier]) VALUES ('" + contact.fullName + "', '" + contact.email + "', '" + contact.subject + "', '" + contact.message + "', '" + userIdentifier + "')";
                SqlCommand insertcmd = new SqlCommand(insert, con);
                con.Open();
                insertcmd.ExecuteNonQuery();
                con.Close();
                ViewData["thanks"] = string.Concat("Thank you for contacting us " + contact.fullName);
            }
            return View();
        }
        /* -------------Contact Functionality End----------------- */

        /* ---- Signup/ Creat an account Functionality Start --- */

        [HttpGet]
        public IActionResult Signup()
        {
            ViewData["Error"] = HttpContext.Session.GetString(SessionProfileError);
            ViewData["Error2"] = HttpContext.Session.GetString(SessionLoginError);
            return View();
        }

        [HttpPost]
        public IActionResult Signup(User user)
        {
            if (ModelState.IsValid)
            {
                SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=mvcFinalProject;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
                string checkQuery = "SELECT * FROM [mvcFinalProject].[dbo].[Users] WHERE email = '" + user.email + "'";
                SqlCommand checkcmd = new SqlCommand(checkQuery, con);
                con.Open();
                SqlDataReader reader = checkcmd.ExecuteReader();
                if (reader.Read())
                {
                    con.Close();
                    HttpContext.Session.SetString(SessionSignupError, "This email is already in use!");
                    ViewData["Error"] = HttpContext.Session.GetString(SessionSignupError);
                    return View();
                }
                else
                {
                    con.Close();
                    string insert = "INSERT INTO [mvcFinalProject].[dbo].[Users] ([fname],[lname],[email], [password]) VALUES ('" + user.fname + "', '" + user.lname + "', '" + user.email + "' , '" + user.password + "' )";
                    SqlCommand insertcmd = new SqlCommand(insert, con);
                    con.Open();
                    insertcmd.ExecuteNonQuery();
                    con.Close();
                    HttpContext.Session.SetString(SessionFName, user.fname);
                    HttpContext.Session.SetString(SessionLName, user.lname);
                    HttpContext.Session.SetString(SessionEmail, user.email);
                    return RedirectToAction("Profile");
                }
                //return Content($"Thank You for signing up {user.fname} {user.lname}! Your email is {user.email}");        
            }
            return View();
        }

        /* ---- Signup Functionality End ---- */

        /* ---- Login Functionality Start --- */
        [HttpPost]
        public IActionResult Login(User user)
        {
            SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=mvcFinalProject;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            string checkQuery = "SELECT * FROM [mvcFinalProject].[dbo].[Users] WHERE email = '" + user.email + "' AND password= '" + user.password + "'";
            SqlCommand checkcmd = new SqlCommand(checkQuery, con);
            con.Open();
            SqlDataReader reader = checkcmd.ExecuteReader();
            if (reader.Read())
            {
                user.fname = String.Format("{0}", reader[1]);
                user.lname = String.Format("{0}", reader[2]);
                HttpContext.Session.SetString(SessionFName, user.fname);
                HttpContext.Session.SetString(SessionLName, user.lname);
                HttpContext.Session.SetString(SessionEmail, user.email);
                return RedirectToAction("Profile");
            }
            else
            {
                HttpContext.Session.SetString(SessionLoginError, "This email or password is wrong!");
                return RedirectToAction("Signup");
            }
        }
        /* ---- Login Functionality End ---- */

        /* ---- Logout Functionality Start ---- */
        public IActionResult Logout()
        {
            HttpContext.Session.SetString(SessionFName, "");
            HttpContext.Session.SetString(SessionLName, "");
            HttpContext.Session.SetString(SessionEmail, "");
            HttpContext.Session.SetString(SessionProfileError, "");
            HttpContext.Session.SetString(SessionSignupError, "");
            HttpContext.Session.SetString(SessionLoginError, "");
            return RedirectToAction("Signup");
        }
        /* ---- Logout Functionality End ---- */


        /* ---- Profile Functionality Start ---- */


        public async Task<IActionResult> Profile()
        {
            List<msg> mess = new List<msg>();
            if (string.IsNullOrEmpty(HttpContext.Session.GetString(SessionEmail)))
            {
                HttpContext.Session.SetString(SessionProfileError, "You need to sign up or log in first!");
                return RedirectToAction("Signup");
            }
            else
            {
                // Weather API
                var client = new HttpClient();
                var request = new HttpRequestMessage
                {
                    Method = HttpMethod.Get,
                    RequestUri = new Uri("https://weatherapi-com.p.rapidapi.com/current.json?q=toronto"),
                    Headers =
                {
                    { "X-RapidAPI-Key", "9323f540e7msh419c9bee785f588p12528cjsnf142c4d9c9e3" },
                    { "X-RapidAPI-Host", "weatherapi-com.p.rapidapi.com" },
                },
                };
                using (var response = await client.SendAsync(request))
                {
                    response.EnsureSuccessStatusCode();
                    var body = await response.Content.ReadAsStringAsync();
                    //Console.WriteLine(body);
                    //HttpContext.Session.SetString(SessionApi, body);
                    ViewBag.weather = JObject.Parse(body)["current"];

                }
                ViewData["fname"] = HttpContext.Session.GetString(SessionFName);
                ViewData["lname"] = HttpContext.Session.GetString(SessionLName);
                ViewData["email"] = HttpContext.Session.GetString(SessionEmail);

                // contact messages
                SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=mvcFinalProject;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
                string checkQuery = "SELECT * FROM [mvcFinalProject].[dbo].[Mes] WHERE userIdentifier =  '" + HttpContext.Session.GetString(SessionEmail) + "'";
                SqlCommand checkcmd = new SqlCommand(checkQuery, con);
                con.Open();
                SqlDataReader reader = checkcmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        msg message = new msg();
                        message.fullName = reader.GetString("fullName");
                        message.subject = reader.GetString("subject");
                        message.message = reader.GetString("message");
                        message.dateTime = reader.GetDateTime("dateTime").ToLongDateString();
                        mess.Add(message);
                    }
                    ViewBag.messages = mess;
                    return View();
                }
                else
                {
                    ViewData["noMessage"] = "There is no message to show";
                    return View();
                }
            }
        }


        /* ------------- Gallery Functionality Start----------------- */
        public IActionResult Gallery()
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString(SessionEmail)))
            {
                HttpContext.Session.SetString("SessionProfileError", "You need to Registration or log in first!");
                return RedirectToAction("Signup");
            }
            else
            {
                return View();
            }
        }
        /* -------------Gallery Functionality End ----------------- */



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}