﻿namespace ASP.netMVCfinalProject.Models
{
    public class Contact
    {
        public string fullName { get; set; }
        public string email { get; set; }
        public string subject { get; set; }
        public string message { get; set; }
    }
}
