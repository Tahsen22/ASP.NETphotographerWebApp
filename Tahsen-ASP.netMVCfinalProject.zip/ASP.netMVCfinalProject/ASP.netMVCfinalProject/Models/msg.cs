﻿namespace ASP.netMVCfinalProject.Models
{
    public class msg
    {
        public string fullName { get; set; }
        public string subject { get; set; }
        public string message { get; set; }
        public string dateTime { get; set; }
    }
}
